@extends('layouts.app-tenant')
@section('content')

<!-- Content -->

<style type="text/css">
    
    
        .imageOutput img
            {
                width:200px;
                height:auto;
            }

</style>

<div class="container-xxl flex-grow-1 container-p-y">
<h4 class="py-3 mb-4"><span class="text-muted fw-light">Tenantuser /</span> Edit</h4>

        <!-- Help Topics: Start -->
        <section class="section-py">
            <div class="container">
                
                <div class="row">
                    <div class="row gy-4 gy-md-0">
                        <!-- list topic -->
                        
                        <div class="col-md-12 mt-3">
                            <div class="card border shadow-none h-100">


                                <div class="card-header header-elements">
                                    <h5 class="me-2">Edit Tenantuser</h5>

                                      <div class="card-header-elements ms-auto">
                                        <a href = "{{ route('tenant.branch') }}" class="btn btn-primary waves-effect waves-light">
                                          <span class="tf-icon mdi mdi-eye me-1"></span>Tenantuser List
                                        </a>
                                      </div>
                                    </div>



                                
                                <div class="card-body text-center">

  <div class="row">
                    <div class="row gy-4 gy-md-0">
                        <!-- list topic -->
                        
                        <div class="col-md-8 mt-3">



                    <form class="pt-0" method = "post" action = "{{ route('tenantuser.update') }}">
                      <!-- Currency Name-->
                      {{ csrf_field() }}

                       <input type="hidden" name="id" value="{{ $tenantuser->id }}">
                       <input type="hidden" name="_method" value="PUT">

                       <div class="form-floating form-floating-outline mb-4">
                        <select
                              id="tenant_id"
                              name="tenant_id"
                              class="form-select"
                              data-allow-clear="true" required>
                              <option value="">Select tenant</option>    
                             @foreach($tenant as $ten)

                               @php 

                                $value =  ($tenantuser->tenant_id == $ten->id) ? 'Selected' : '';  

                              @endphp

                               <option value="{{ $ten->id }}" {{ $value }} >{{ $ten->company_name }}</option> 
                              @endforeach                                   
                            </select>
                            <label for="tenant_id">Select Tenant Name</label>
                       </div>
                   
                      @error('tenant_id')
                       <div class="alert alert-danger">{{ $message }}</div>
                      @enderror


                       <div class="form-floating form-floating-outline mb-4">
                        <select
                              id="branch_id"
                              name="branch_id"
                              class="form-select"
                              data-allow-clear="true" required>
                              <option value="">Select branch</option>    
                              @foreach($branch as $bran)

                               @php 

                                $selectvalue =  ($tenantuser->branch_id == $bran->id) ? 'Selected' : '';  

                              @endphp

                               <option value="{{ $bran->id }}" {{ $selectvalue }}>{{ $bran->branchname }}</option> 
                              @endforeach                         
                            </select>
                            <label for="branch_id">Select Branch Name</label>
                       </div>
                   
                      @error('branch_id')
                       <div class="alert alert-danger">{{ $message }}</div>
                      @enderror

                       <div class="form-floating form-floating-outline mb-4">
                        <select
                              id="role"
                              name="role"
                              class="form-select"
                              data-allow-clear="true" required>
                              <option value="">Select role</option>  
                              <option value="Tenant Admin" {{ $tenantuser->role == "Tenant Admin" ? 'Selected' :'' }}>Tenant Admin</option>  
                              <option value="Branch Admin" {{ $tenantuser->role == "Branch Admin" ? 'Selected' :'' }}>Branch Admin</option>
                              <option value="Cashier" {{ $tenantuser->role == "Cashier" ? 'Selected' :'' }} >Cashier</option>
                                                 
                            </select>
                            <label for="role">Select Role</label>
                       </div>
                   
                      @error('role')
                       <div class="alert alert-danger">{{ $message }}</div>
                      @enderror


                     

                     
                      <!-- Submit and reset -->
                      <div class="mb-3">
                        <button type="submit" class="btn btn-success me-sm-3 me-1 data-submit">Update</button>
                        <button type="reset" class="btn btn-outline-success" data-bs-dismiss="offcanvas">Discard</button>
                      </div>
                    </form>
                 
</div></div></div>
                                </div>
                            </div>
                        </div>
                       
                        <!-- list topic -->


                    </div>
                </div>
            </div>
        </section>
        <!-- Currency: End -->
</div>
<!--/ Content -->

@endsection

