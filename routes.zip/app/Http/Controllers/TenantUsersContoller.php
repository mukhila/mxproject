<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Brian2694\Toastr\Facades\Toastr;
use App\Models\Tenant;
use App\Models\Branch;
use App\Models\TenantUsers;
use Auth;


class TenantUsersContoller extends Controller
{
    public function list()
    {
        $tenantusers = TenantUsers::where('delete_status',0)->paginate(10);
        return view('tenantuser.index')->with([
            'tenantusers' => $tenantusers
        ]);
    }
    public function add()
    {
        $tenant = Tenant::where('delete_status',0)->get();
        $branch = Branch::where('delete_status',0)->get();
        return view('tenantuser.create')->with([
            'tenant' => $tenant,
            'branch' => $branch
        ]);
    }
    public function save(Request $request)
    {
        $request->validate([            
            'tenant_id' => 'required',
            'branch_id' => 'required',               
            'role' => 'required',                                    
        ]);

        $tenantuser = new TenantUsers;
        $tenantuser->tenant_id = $request->tenant_id; 
        $tenantuser->branch_id = $request->branch_id;
        $tenantuser->role = $request->role;
        $tenantuser->user_id = Auth::user()->id;
        $tenantuser->status = 'Active';
        $tenantuser->save();   
        return redirect('/tenant/tenantuser')->with('success', 'TenantUsers successfully created');  
    }

    public function edit($id)
    {
        $tenantuser = TenantUsers::where('id',$id)->first();
        $tenant = Tenant::where('delete_status',0)->get();
        $branch = Branch::where('delete_status',0)->get();
        return view('tenantuser.edit')->with([
            'branch' => $branch,
            'tenant' => $tenant,
            'tenantuser'=> $tenantuser
        ]);
    }

    public function update(Request $request)
    {
         $id = $request->id;
         $request->validate([
            'id' => 'required',
            'tenant_id' => 'required',
            'branch_id' => 'required',               
            'role' => 'required',                        
        ]);
         
        $tenantuser = TenantUsers::find($id);
        $tenantuser->tenant_id = $request->tenant_id; 
        $tenantuser->branch_id = $request->branch_id;
        $tenantuser->role = $request->role;  
        $tenantuser->status = 'Active';
        $tenantuser->save();       
        return redirect('/tenant/tenantuser')->with('success', 'TenantUsers successfully Updated');

    }

    public function updatestatus($id) {
        $tenantuser = TenantUsers::where('id', '=', $id)->select('status')->first();
        $status = $tenantuser->status;
        $tenantuserstatus = 'Active';
        if($status == 'Active') {
            $tenantuserstatus = 'Inactive';
        }
        TenantUsers::where('id', '=', $id)->update(['status' => $tenantuserstatus]);
        return redirect('/tenant/tenantuser')->with('success', 'TenantUsers status successfully updated');
    }
    public function destroy($id)
    {
        TenantUsers::where('id', '=', $id)->update(['delete_status' => 1]);
        return redirect('/tenant/tenantuser')->with('success', 'TenantUsers details successfully deleted');
    }
}
